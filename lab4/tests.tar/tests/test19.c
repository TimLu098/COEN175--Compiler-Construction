int f(int x, ...);

int f(int x, ...) { return 0; }

int f(int x, ...) { return 0; }		/* redefinition of 'f' */

int f(int x, ...) { return 0; }		/* redefinition of 'f' */

int f(int x, ...);
