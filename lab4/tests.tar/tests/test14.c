int x, y;
int y, x;

int a[10], ***p;
int ***p, a[10];

char **b[3], **q;
char **q, **b[3], c[3];
char c[3];

int a[10], ***p;
