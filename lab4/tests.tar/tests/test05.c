char **a(void);

int f(int x), *g(int y);
int *g(int y), f(int x);

char **a(void);

int f(int x), *g(int y);
