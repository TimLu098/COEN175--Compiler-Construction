char **a(int x, int *y);

int f(int f, ...), *g(int y, double *z, double **q, ...);
int *g(int y, double *z, double **q, ...), f(int g, ...);

char **a(int x, int *y);

int f(int a, ...), *g(int a, double *b, double **c, ...);
