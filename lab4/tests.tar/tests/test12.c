int f(int x, int y, int *x);		/* redeclaration of 'x' */

int g(int x, int y, int y);		/* redeclaration of 'y' */

int h(int x, int y, int z);
