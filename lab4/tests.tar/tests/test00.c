int main(void)
{
    int x, y, z;

    {
	int *x, *y, *z;

	{
	    char *x, *y, *z;
	}
    }
}
