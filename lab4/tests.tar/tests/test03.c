int main(void)
{
    int x, y, *x;		/* redeclaration of 'x' */

    {
	int a, b, a;		/* redeclaration of 'a' */
	int i, j, k;
    }
}
