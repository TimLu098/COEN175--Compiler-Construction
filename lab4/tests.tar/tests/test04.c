int x, y;
int y, x;

int a[10], *p;
int *p, a[10];

char *b[10], **q;
char **q, *b[10];
