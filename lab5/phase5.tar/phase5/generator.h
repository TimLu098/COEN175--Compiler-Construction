# ifndef GENERATOR_H
# define GENERATOR_H_H

# include "Tree.h"
# include "Scope.h"

void generateGlobals(Scope *scope);

# endif 